#!/usr/bin/env python

def getBlockDict(file):
	"""
	file is from Qemu stderr.
	Get block dictionary from Qemu with option as <-d in_asm>.
	The key is the first instructions address.
	The value is a list of instructions in this block.
	"""
	blockDict = {}
	with open(file, 'r') as f:
		key = None
		for line in f:
			if line.startswith("----------------") or line.startswith("IN:"):
				continue
			elif line == '\n':
				key = None
				continue

			line = line.split(':')[0]
			if not key:
				key = int(line, 16)
				blockDict[key] = [line]
			else:
				blockDict[key].append(line)

	# print(str(blockDict))
	return blockDict


def getTraceList(file):
	"""
	file is from Qemu stdout.
	Return a list containing the first instruction in a block
	"""
	blockList = []
	with open(file, 'r') as f:
		for line in f:
			line = line.split(':')[1].strip()
			blockList.append(int("0x"+line, 16))

	# print(blockList)
	return blockList


def getInsTrace(blockFile, blockTraceFile):
	"""
	return Qemu instruction trace
	"""
	insTrace = []
	blockDict = getBlockDict(blockFile)
	blockList = getTraceList(blockTraceFile)

	for key in blockList:
		insTrace.extend(blockDict[key])

	return insTrace


if __name__ == "__main__":

	insTrace = getInsTrace('./block', './trace')

	with open('insTrace', 'w') as f:
		for line in insTrace:
			f.write(line+'\n')



