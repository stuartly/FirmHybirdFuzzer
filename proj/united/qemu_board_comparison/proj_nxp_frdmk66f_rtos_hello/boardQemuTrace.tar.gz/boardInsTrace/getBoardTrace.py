#!/usr/bin/env python

def getTraceList(file):
	"""
	get a trace list from a file
	"""
	traceList = []
	with open(file, 'r') as f:
		for line in f:
			if line.startswith("Inst"):
				continue

			line = line.split()[1].strip()
			traceList.append(line)
	# print(traceList)
	return traceList

if __name__ == "__main__":

	trace = []
	for i in range(1, 7):
		trace.extend(getTraceList(str(i)+".tsv"))

	with open("./insTrace", 'w') as f:
		for line in trace:
			f.write(line+'\n')

